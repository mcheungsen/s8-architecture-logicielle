package model;

public class Main {
    public static void main(String[] args) {
        System.out.println("Bravo, vous avez réussi l'exercice 1!");
    }
}
